$(function(){
	$('#mkCarousel').mkCarousel({
		offset: 130,
		mobileOffset: 60
	});
});