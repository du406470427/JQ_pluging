$(document).ready(function () {

	$('.bar').jqbar({ label: 'ASP.NET', value: 99, barColor: '#D64747' });

});