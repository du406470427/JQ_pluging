$(function(){
	$('ul.nav').hoverifyBootnav({
		'duration_effect_on' : 400,
		'duration_effect_off' : 1000,		
		'color' : 'black'
	});
});