$(function() {

	$(".test-plugin").magnifierRentgen();

})